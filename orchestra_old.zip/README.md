#Note

This repository contains multiple files which was used for testing but,

Controller (2018-2019)

These are the main files to run.

It was tested on linux ubuntu 16.04 and to run it use pycharm and check the ports at which controller for proper broadcast.
